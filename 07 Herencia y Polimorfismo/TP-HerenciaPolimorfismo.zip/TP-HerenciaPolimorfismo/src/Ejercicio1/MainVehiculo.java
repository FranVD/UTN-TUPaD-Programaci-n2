
package Ejercicio1;

public class MainVehiculo {


    public static void main(String[] args) {
        Auto auto = new Auto("VW", "GOL", 4);
        auto.mostrarInfo();

    }
    
}