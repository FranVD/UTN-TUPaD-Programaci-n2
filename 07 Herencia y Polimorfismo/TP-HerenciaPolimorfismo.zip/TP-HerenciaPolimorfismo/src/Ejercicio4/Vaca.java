package Ejercicio4;

public class Vaca extends Animal {
        @Override
    public void hacerSonido() {
        System.out.println("Muuu");
    }

}