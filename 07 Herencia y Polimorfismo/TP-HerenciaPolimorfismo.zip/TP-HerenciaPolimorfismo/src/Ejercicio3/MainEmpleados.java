package Ejercicio3;

public class MainEmpleados {
    public static void main(String[] args) {
        Empleado[] empleados = {
            new EmpleadoPlanta("Juan", 50000),
            new EmpleadoTemporal("Ana", 20, 1500)
        };

        for (Empleado e : empleados) {
            System.out.println("Empleado: " + e.nombre + " - Sueldo: " + e.calcularSueldo());
        }
    }

}