package ejercicio3;

public class MainUniversidad {

    public static void main(String[] args) {

        Universidad uni = new Universidad("Universidad Nacional");

        Profesor prof1 = new Profesor("P1", "Ana López", "Matemática");
        Profesor prof2 = new Profesor("P2", "Carlos Pérez", "Programación");
        Profesor prof3 = new Profesor("P3", "María García", "Estadística");

        uni.agregarProfesor(prof1);
        uni.agregarProfesor(prof2);
        uni.agregarProfesor(prof3);

        Curso c1 = new Curso("MAT101", "Álgebra I");
        Curso c2 = new Curso("PROG1", "Programación I");
        Curso c3 = new Curso("PROG2", "Programación II");
        Curso c4 = new Curso("EST101", "Estadística I");
        Curso c5 = new Curso("BD101", "Bases de Datos");

        uni.agregarCurso(c1);
        uni.agregarCurso(c2);
        uni.agregarCurso(c3);
        uni.agregarCurso(c4);
        uni.agregarCurso(c5);

        uni.asignarProfesorACurso("MAT101", "P1");
        uni.asignarProfesorACurso("PROG1", "P2");
        uni.asignarProfesorACurso("PROG2", "P2");
        uni.asignarProfesorACurso("EST101", "P3");
        uni.asignarProfesorACurso("BD101", "P2");

        uni.listarProfesores();
        System.out.println();
        uni.listarCursos();

        System.out.println("\n=== Cambio de profesor del curso PROG2 a P3 ===");
        uni.asignarProfesorACurso("PROG2", "P3");
        uni.listarCursos();

        System.out.println("\n=== Eliminando curso BD101 ===");
        uni.eliminarCurso("BD101");
        uni.listarCursos();
        System.out.println();
        prof2.listarCursos();

        System.out.println("\n=== Eliminando profesor P2 ===");
        uni.eliminarProfesor("P2");
        uni.listarProfesores();
        System.out.println();
        uni.listarCursos();

        System.out.println();
        uni.reporteCantidadCursosPorProfesor();
    }
}
