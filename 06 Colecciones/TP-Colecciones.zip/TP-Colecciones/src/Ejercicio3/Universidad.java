package ejercicio3;

import java.util.ArrayList;
import java.util.List;

public class Universidad {

    private String nombre;
    private List<Profesor> profesores = new ArrayList<>();
    private List<Curso> cursos = new ArrayList<>();

    public Universidad(String nombre) {
        this.nombre = nombre;
    }

    public void agregarProfesor(Profesor p) {
        profesores.add(p);
    }

    public void agregarCurso(Curso c) {
        cursos.add(c);
    }

    public Profesor buscarProfesorPorId(String id) {
        for (Profesor p : profesores) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }

    public Curso buscarCursoPorCodigo(String codigo) {
        for (Curso c : cursos) {
            if (c.getCodigo().equals(codigo)) {
                return c;
            }
        }
        return null;
    }

    public void asignarProfesorACurso(String codigoCurso, String idProfesor) {
        Curso curso = buscarCursoPorCodigo(codigoCurso);
        Profesor profesor = buscarProfesorPorId(idProfesor);

        if (curso != null && profesor != null) {
            curso.setProfesor(profesor);
        } else {
            System.out.println("No se pudo asignar: datos incorrectos.");
        }
    }

    public void listarProfesores() {
        System.out.println("=== Profesores en " + nombre + " ===");
        for (Profesor p : profesores) {
            p.mostrarInfo();
        }
    }

    public void listarCursos() {
        System.out.println("=== Cursos en " + nombre + " ===");
        for (Curso c : cursos) {
            c.mostrarInfo();
        }
    }

    public void eliminarCurso(String codigo) {
        Curso c = buscarCursoPorCodigo(codigo);
        if (c != null) {
            c.setProfesor(null);
            cursos.remove(c);
            System.out.println("Curso " + codigo + " eliminado.");
        } else {
            System.out.println("Curso " + codigo + " no encontrado.");
        }
    }

    public void eliminarProfesor(String id) {
        Profesor p = buscarProfesorPorId(id);
        if (p != null) {
            for (Curso c : new ArrayList<>(p.getCursos())) {
                c.setProfesor(null);
            }
            profesores.remove(p);
            System.out.println("Profesor " + id + " eliminado.");
        } else {
            System.out.println("Profesor " + id + " no encontrado.");
        }
    }

    public void reporteCantidadCursosPorProfesor() {
        System.out.println("=== Reporte: cantidad de cursos por profesor ===");
        for (Profesor p : profesores) {
            System.out.println(p.getId() + " - " + p.getNombre()
                    + ": " + p.getCursos().size() + " cursos");
        }
    }
}
