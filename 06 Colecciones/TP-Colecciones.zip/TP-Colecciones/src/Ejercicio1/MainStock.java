package ejercicio1;

public class MainStock {

    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        Producto p1 = new Producto("P001", "Leche", 1200, 10, CategoriaProducto.ALIMENTOS);
        Producto p2 = new Producto("P002", "Televisor", 250000, 3, CategoriaProducto.ELECTRONICA);
        Producto p3 = new Producto("P003", "Remera", 8000, 20, CategoriaProducto.ROPA);
        Producto p4 = new Producto("P004", "Sábana", 15000, 5, CategoriaProducto.HOGAR);
        Producto p5 = new Producto("P005", "Auriculares", 18000, 12, CategoriaProducto.ELECTRONICA);

        inventario.agregarProducto(p1);
        inventario.agregarProducto(p2);
        inventario.agregarProducto(p3);
        inventario.agregarProducto(p4);
        inventario.agregarProducto(p5);

        System.out.println("=== LISTA COMPLETA ===");
        inventario.listarProductos();

        System.out.println("\n=== BUSCAR P003 ===");
        Producto buscado = inventario.buscarProductoPorId("P003");
        if (buscado != null) {
            buscado.mostrarInfo();
        }

        System.out.println("\n=== ELECTRÓNICA ===");
        for (Producto p : inventario.filtrarPorCategoria(CategoriaProducto.ELECTRONICA)) {
            p.mostrarInfo();
        }

        System.out.println("\n=== ELIMINAR P001 ===");
        inventario.eliminarProducto("P001");
        inventario.listarProductos();

        System.out.println("\n=== ACTUALIZAR STOCK P002 ===");
        inventario.actualizarStock("P002", 7);
        inventario.buscarProductoPorId("P002").mostrarInfo();

        System.out.println("\nTotal de stock: " + inventario.obtenerTotalStock());

        System.out.println("\n=== PRODUCTO CON MÁS STOCK ===");
        Producto mayor = inventario.obtenerProductoConMayorStock();
        if (mayor != null) {
            mayor.mostrarInfo();
        }

        System.out.println("\n=== PRECIOS ENTRE 1000 Y 3000 ===");
        for (Producto p : inventario.filtrarProductosPorPrecio(1000, 3000)) {
            p.mostrarInfo();
        }

        System.out.println("\n=== CATEGORÍAS DISPONIBLES ===");
        inventario.mostrarCategoriasDisponibles();
    }
}
