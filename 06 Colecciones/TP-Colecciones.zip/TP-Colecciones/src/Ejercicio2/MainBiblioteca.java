package ejercicio2;

public class MainBiblioteca {

    public static void main(String[] args) {
        Biblioteca biblio = new Biblioteca("Biblioteca Central");

        Autor a1 = new Autor("A1", "Gabriel García Márquez", "Colombia");
        Autor a2 = new Autor("A2", "Julio Cortázar", "Argentina");
        Autor a3 = new Autor("A3", "Isabel Allende", "Chile");

        biblio.agregarLibro("ISBN1", "Cien Años de Soledad", 1967, a1);
        biblio.agregarLibro("ISBN2", "Rayuela", 1963, a2);
        biblio.agregarLibro("ISBN3", "La Casa de los Espíritus", 1982, a3);
        biblio.agregarLibro("ISBN4", "El Amor en los Tiempos del Cólera", 1985, a1);
        biblio.agregarLibro("ISBN5", "Bestiario", 1951, a2);

        System.out.println("=== LISTA COMPLETA ===");
        biblio.listarLibros();

        System.out.println("\n=== BUSCAR ISBN3 ===");
        Libro buscado = biblio.buscarLibroPorIsbn("ISBN3");
        if (buscado != null) {
            buscado.mostrarInfo();
        }

        System.out.println("\nCantidad de libros: " + biblio.obtenerCantidadLibros());

        System.out.println("\n=== LIBROS DEL AÑO 1963 ===");
        for (Libro l : biblio.filtrarLibrosPorAnio(1963)) {
            l.mostrarInfo();
        }

        System.out.println("\n=== AUTORES DISPONIBLES ===");
        biblio.mostrarAutoresDisponibles();

        System.out.println("\n=== ELIMINAR ISBN2 ===");
        biblio.eliminarLibro("ISBN2");
        biblio.listarLibros();
    }
}

