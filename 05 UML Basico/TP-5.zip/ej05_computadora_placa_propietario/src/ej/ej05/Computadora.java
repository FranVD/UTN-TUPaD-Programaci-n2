package ej.ej05;

public class Computadora {
private String marca;
private String numeroSerie;
private PlacaMadre placaMadre; // composición
private Propietario propietario; // asociación bi

public Computadora(String marca,String numeroSerie,String modeloPM,String chipset,Propietario propietario){
    this.marca=marca; this.numeroSerie=numeroSerie;
    this.placaMadre=new PlacaMadre(modeloPM,chipset);
    this.propietario=propietario;
    if(propietario!=null) propietario.setComputadora(this);
}
}
