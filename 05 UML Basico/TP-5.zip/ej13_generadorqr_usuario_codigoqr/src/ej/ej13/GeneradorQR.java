package ej.ej13;

public class GeneradorQR {
public void generar(String valor, Usuario usuario){
    CodigoQR qr = new CodigoQR(valor, usuario); // dependencia de creación
    System.out.println("QR generado para " + usuario.getNombre() + " con valor: " + valor);
}
}
