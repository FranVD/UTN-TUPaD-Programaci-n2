package ej.ej01;

public class Titular {
private String nombre;
private String dni;
private Pasaporte pasaporte; // lado inverso

public Titular(String nombre, String dni){
    this.nombre = nombre;
    this.dni = dni;
}
public void setPasaporte(Pasaporte p){ this.pasaporte = p; }
}
