package ej.ej01;

public class Pasaporte {
private String numero;
private String fechaEmision;
private Foto foto;         // composición
private Titular titular;   // asociación bidireccional

public Pasaporte(String numero, String fechaEmision, String imagen, String formato, Titular titular){
    this.numero = numero;
    this.fechaEmision = fechaEmision;
    this.foto = new Foto(imagen, formato); // composición: creado adentro
    this.titular = titular;
    if(titular != null){
        titular.setPasaporte(this);
    }
}
public String getNumero(){ return numero; }
public Titular getTitular(){ return titular; }
}
