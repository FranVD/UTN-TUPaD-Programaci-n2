package ej.ej10;

public class CuentaBancaria {
private String cbu;
private double saldo;
private ClaveSeguridad clave; // composición
private Titular titular;      // asociación bi

public CuentaBancaria(String cbu,double saldo,String codigo,String ultimaModificacion,Titular titular){
    this.cbu=cbu; this.saldo=saldo;
    this.clave=new ClaveSeguridad(codigo,ultimaModificacion);
    this.titular=titular;
    if(titular!=null) titular.setCuenta(this);
}
}
