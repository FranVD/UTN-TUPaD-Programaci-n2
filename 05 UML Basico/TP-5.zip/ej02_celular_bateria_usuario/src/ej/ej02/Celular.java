package ej.ej02;

public class Celular {
private String imei;
private String marca;
private String modelo;
private Bateria bateria;     // agregación
private Usuario usuario;     // asociación bidireccional

public Celular(String imei,String marca,String modelo,Bateria bateria,Usuario usuario){
    this.imei=imei; this.marca=marca; this.modelo=modelo;
    this.bateria=bateria; // agregación: se inyecta
    this.usuario=usuario;
    if(usuario!=null) usuario.setCelular(this);
}
}
