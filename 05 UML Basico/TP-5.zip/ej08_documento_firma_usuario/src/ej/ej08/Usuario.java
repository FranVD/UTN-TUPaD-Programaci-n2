package ej.ej08;

public class Usuario {
private String nombre;
private String email;
public Usuario(String nombre,String email){ this.nombre=nombre; this.email=email; }
}
