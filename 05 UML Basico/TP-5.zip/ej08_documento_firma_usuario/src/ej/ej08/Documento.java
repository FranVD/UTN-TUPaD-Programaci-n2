package ej.ej08;

public class Documento {
private String titulo;
private String contenido;
private FirmaDigital firma; // composición

public Documento(String titulo,String contenido,String hash,String fecha,Usuario usuario){
    this.titulo=titulo; this.contenido=contenido;
    this.firma=new FirmaDigital(hash,fecha,usuario);
}
}
