package ej.ej12;

public class Impuesto {
private double monto;
private Contribuyente contribuyente; // asociación
public Impuesto(double monto,Contribuyente c){ this.monto=monto; this.contribuyente=c; }
public double getMonto(){ return monto; }
public Contribuyente getContribuyente(){ return contribuyente; }
}
