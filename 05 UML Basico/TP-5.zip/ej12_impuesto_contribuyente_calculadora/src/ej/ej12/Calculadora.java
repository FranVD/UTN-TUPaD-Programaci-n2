package ej.ej12;

public class Calculadora {
public void calcular(Impuesto impuesto){
    System.out.println("Calculando impuesto sobre: " + impuesto.getMonto() + " de " + impuesto.getContribuyente().getNombre());
}
}
