package ej.ej14;

public class Render {
private String formato;
private Proyecto proyecto; // asociación ->
public Render(String formato,Proyecto proyecto){ this.formato=formato; this.proyecto=proyecto; }
}
