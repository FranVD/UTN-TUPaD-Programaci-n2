package ej.ej14;

public class EditorVideo {
public void exportar(String formato, Proyecto proyecto){
    Render render = new Render(formato, proyecto); // dependencia de creación
    System.out.println("Exportando proyecto " + proyecto.getNombre() + " a " + formato);
}
}
