package parte1;

public enum EstadoPedido {
    PENDIENTE,
    PAGADO,
    ENVIADO,
    CANCELADO
}
