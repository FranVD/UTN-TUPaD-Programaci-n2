package parte1;

public interface Notificable {
    void notificarCambioEstado(String mensaje);
}
