package parte1;

public class TarjetaCredito implements PagoConDescuento {

    private String numero;
    private String titular;

    public TarjetaCredito(String numero, String titular) {
        this.numero = numero;
        this.titular = titular;
    }

    @Override
    public double aplicarDescuento(double monto) {
        return monto * 0.90; // 10% de descuento
    }

    @Override
    public void procesarPago(double monto) {
        System.out.println("Pagando $" + monto + " con Tarjeta de " + titular +
                " (nro " + numero + ")");
    }
}

