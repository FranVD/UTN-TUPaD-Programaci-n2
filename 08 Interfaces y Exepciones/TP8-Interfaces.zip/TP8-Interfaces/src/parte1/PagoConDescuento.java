package parte1;

public interface PagoConDescuento extends Pago {
    double aplicarDescuento(double monto);
}
