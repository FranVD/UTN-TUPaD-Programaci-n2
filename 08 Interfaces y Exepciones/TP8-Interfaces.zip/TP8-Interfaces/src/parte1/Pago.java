package parte1;

public interface Pago {
    void procesarPago(double monto);
}
