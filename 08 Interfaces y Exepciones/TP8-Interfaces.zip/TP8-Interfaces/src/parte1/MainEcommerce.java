package parte1;

public class MainEcommerce {

    public static void main(String[] args) {
        Cliente cliente = new Cliente("Franco", "franco@example.com");
        Pedido pedido = new Pedido(cliente);

        Producto p1 = new Producto("Mouse gamer", 15000);
        Producto p2 = new Producto("Teclado mecánico", 30000);

        pedido.agregarProducto(p1);
        pedido.agregarProducto(p2);

        double total = pedido.calcularTotal();
        System.out.println("Total del pedido: $" + total);

        PagoConDescuento pago = new TarjetaCredito("1234-5678-9999-0000", "Franco");
        double totalConDescuento = pago.aplicarDescuento(total);
        System.out.println("Total con descuento: $" + totalConDescuento);
        pago.procesarPago(totalConDescuento);

        pedido.cambiarEstado(EstadoPedido.PAGADO);
        pedido.cambiarEstado(EstadoPedido.ENVIADO);
    }
}
