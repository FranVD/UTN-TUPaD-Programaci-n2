package parte1;

public interface Pagable {
    double calcularTotal();
}
