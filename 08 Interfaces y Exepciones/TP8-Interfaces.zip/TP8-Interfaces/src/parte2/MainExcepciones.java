package parte2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class MainExcepciones {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // 1) División segura
        try {
            System.out.println("=== División segura ===");
            System.out.print("Ingrese dividendo: ");
            int a = Integer.parseInt(scanner.nextLine());
            System.out.print("Ingrese divisor: ");
            int b = Integer.parseInt(scanner.nextLine());
            int resultado = a / b;
            System.out.println("Resultado: " + resultado);
        } catch (ArithmeticException e) {
            System.out.println("Error: no se puede dividir por cero.");
        }

        // 2) Conversión de cadena a número
        try {
            System.out.println("\n=== Conversión a entero ===");
            System.out.print("Ingrese un número: ");
            String texto = scanner.nextLine();
            int numero = Integer.parseInt(texto);
            System.out.println("Número convertido: " + numero);
        } catch (NumberFormatException e) {
            System.out.println("Error: el texto ingresado no es un número entero válido.");
        }

        // 3) Lectura de archivo (FileNotFoundException)
        try {
            System.out.println("\n=== Lectura de archivo simple ===");
            System.out.print("Ingrese ruta del archivo: ");
            String ruta = scanner.nextLine();
            leerArchivoSimple(ruta);
        } catch (FileNotFoundException e) {
            System.out.println("Error: archivo no encontrado.");
        }

        // 4) Excepción personalizada EdadInvalidaException
        try {
            System.out.println("\n=== Validación de edad ===");
            System.out.print("Ingrese edad: ");
            int edad = Integer.parseInt(scanner.nextLine());
            validarEdad(edad);
            System.out.println("Edad válida: " + edad);
        } catch (EdadInvalidaException e) {
            System.out.println("Error de edad: " + e.getMessage());
        }

        // 5) 
        System.out.println("\n=== Lectura con try-with-resources ===");
        System.out.print("Ingrese ruta del archivo: ");
        String ruta2 = scanner.nextLine();
        leerArchivoConTryWithResources(ruta2);

        scanner.close();
    }

    // ejercicio 3
    private static void leerArchivoSimple(String ruta) throws FileNotFoundException {
        FileReader fr = new FileReader(ruta);
        try (BufferedReader br = new BufferedReader(fr)) {
            String linea;
            System.out.println("Contenido:");
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error de lectura: " + e.getMessage());
        }
    }

    // ejercicio 4
    private static void validarEdad(int edad) throws EdadInvalidaException {
        if (edad < 0 || edad > 120) {
            throw new EdadInvalidaException("La edad debe estar entre 0 y 120.");
        }
    }

    // ejercicio 5 – try-with-resources explícito
    private static void leerArchivoConTryWithResources(String ruta) {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            System.out.println("Contenido:");
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: archivo no encontrado.");
        } catch (IOException e) {
            System.out.println("Error de lectura: " + e.getMessage());
        }
    }
}
